angular.module('intTemplatesApp')

.controller('TemplatesCtrl', function($scope){

    // controller logic goes here
    console.log('Template connected');    
});