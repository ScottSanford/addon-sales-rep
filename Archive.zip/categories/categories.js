angular.module('intTemplatesApp')

.controller('CategoriesCtrl', function($scope, mfly){

    $scope.categories = [
    	{icon: 'common/images/data-visualization.png', name: 'Data Visualization'},
    	{icon: 'common/images/calculations.png', name: 'Calculations'},
    	{icon: 'common/images/guided-selling.png', name: 'Guided Selling'},
    	{icon: 'common/images/ui.png', name: 'UI'}
    ];
    
    mfly.search('@Categories').then(function(data){
    	console.log(data);
    });

});