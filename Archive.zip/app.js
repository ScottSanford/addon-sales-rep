angular.module("intTemplatesApp", [
        'ngRoute', 
        ])

        .config(function ($routeProvider, $compileProvider) { 

              $compileProvider.imgSrcSanitizationWhitelist(/^(mfly:\/\/data\/entry|http:\/\/)/);  
              $routeProvider
                .when('/', {
                    templateUrl: 'categories/categories.html',
                    controller: 'CategoriesCtrl'
                })
                .when('/templates', {
                    templateUrl: 'templates/templates.html',
                    controller: 'TemplatesCtrl'
                })
                .otherwise({
                    redirectTo: '/'
                });
                
          });
        